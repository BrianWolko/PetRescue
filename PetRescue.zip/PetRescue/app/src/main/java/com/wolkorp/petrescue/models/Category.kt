package com.wolkorp.petrescue.models

data class Category(val imageURL: String, val categoryName: String)